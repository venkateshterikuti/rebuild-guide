# Rebuild `loan-product-advisor-v6.1.00-request-file-requirements/XSD_LPA_6.1.00_Dec 2025_Updated 012926/mismo/MISMO_3.4.0_B324.xsd`

**Purpose:** Supplied native evidence: preserve this file unchanged.

**Delivery role:** runtime schema dependency. See [client delivery guidance](../../../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** R2. Resolve these through [INPUT_REFERENCES.md](../../../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Obtain this exact target file from the separately supplied source material and copy it byte-for-byte into the target layout. Do not rewrite XML, normalize whitespace, resave the workbook or synthesize a replacement.
2. Preserve the complete native directory structure for relative imports. If unavailable, name this file as missing; do not download an approximate substitute or contact a source URL.


## Verify

Compare the historical byte hash below when rebuilding the same baseline; request schema/catalog checks include the complete native source tree.

Run the relevant checks in [ACCEPTANCE.md](../../../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `7023574` bytes; SHA-256: `2524bcb039fe81c9dbaa98d21550d6585970d29a124d5e51f2c79b97311d834d`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../../../FILE_INDEX.md)
