# Rebuild `loan-product-advisor-v6.1.00-request-file-requirements/LPA v6.1 XML Request File Data Requirements_January_2026.xlsx`

**Purpose:** Supplied native evidence: preserve this file unchanged.

**Delivery role:** native source / catalog rebuild. See [client delivery guidance](../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** R1. Resolve these through [INPUT_REFERENCES.md](../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Obtain this exact target file from the separately supplied source material and copy it byte-for-byte into the target layout. Do not rewrite XML, normalize whitespace, resave the workbook or synthesize a replacement.
2. Preserve the complete native directory structure for relative imports. If unavailable, name this file as missing; do not download an approximate substitute or contact a source URL.


## Verify

Compare the historical byte hash below when rebuilding the same baseline; request schema/catalog checks include the complete native source tree.

Run the relevant checks in [ACCEPTANCE.md](../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `486801` bytes; SHA-256: `e2e808ec27351659f7d3c8f2b14097a1fb358a0e0e259233ac8d9216d51873e3`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../FILE_INDEX.md)
