# Rebuild `docs/IMPLEMENTATION.md`

**Purpose:** Architecture/evidence explanation

**Delivery role:** instructions / metadata. See [client delivery guidance](../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** Verified implementation behavior; R0 for intent and R1–R9 only as references where relevant. Resolve these through [INPUT_REFERENCES.md](../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Write concise original documentation covering module responsibilities, source pins, schema reconstruction, rule scope, privacy, response state, repository changes and allowlisted packaging. Link local deliverables with relative paths so the pack relocates.
2. Keep source evidence, implementation decisions and mock assumptions distinct. The guide is not a place to copy source documents. Do not claim any compiler/service/provider check that was not run.


## Verify

Resolve all local links and commands against implemented files; validation claims match recorded checks, not copied historical prose.

Run the relevant checks in [ACCEPTANCE.md](../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `9321` bytes; SHA-256: `9e9db6d6de6eddd1882466591e79feded702cee14d707e5f3aee5bedfe4c9c48`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../FILE_INDEX.md)
