# Rebuild `tests/test_toolkit.py`

**Purpose:** Behavioral regression coverage for catalog/mapping/validation core.

**Delivery role:** demo / regression verification. See [client delivery guidance](../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** Separately supplied native inputs plus generated synthetic fixtures; no live service. Resolve these through [INPUT_REFERENCES.md](../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Use unittest with temporary directories and actual local schema compilation where relevant. Recreate the named behavioral cases below, using positive and negative assertions on observable outputs/state/call counts.
2. Derive expected source constraints independently from the cited materials, not by calling the function under test to compute its own expected answer. Fake credentials and values only.
3. Block network connections in tests; preserve source bytes. Installed-package tests need paths based on unpacked fixtures/config rather than the original machine.
4. Keep main-suite cases and the pilot application tests distinct. A test count is a baseline inventory, not a substitute for meaningful assertions.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
class ToolkitTests(unittest.TestCase)
  setUpClass(cls)
  xml(self, data=None, profile=None)
  validate(self, xml)
  test_native_catalog_is_reproducible_and_workbook_unchanged(self)
  test_catalog_preserves_credit_vendor_exception(self)
  test_same_field_name_has_distinct_contexts(self)
  test_catalog_tampering_rejected(self)
  test_discovery_preserves_heterogeneous_arrays_without_values(self)
  test_profile_init_is_unreviewed(self)
  test_profile_rejects_unconfirmed_mapping(self)
  test_profile_rejects_stale_catalog(self)
  test_profile_rejects_same_name_wrong_context(self)
  test_data_bindings_cannot_bypass_review(self)
  test_real_xsd_accepts_repeats_and_preserves_relationships(self)
  test_nested_repeat_uses_current_scope(self)
  test_missing_conditional_description_fails_business_not_schema(self)
  test_missing_nonoptional_source_is_not_silently_blank(self)
  test_null_optional_source_is_not_treated_as_missing(self)
  test_unknown_enum_fails_without_fuzzy_mapping(self)
  test_zero_false_precision_and_pointer_escaping(self)
  test_dangling_relationship_rejected(self)
  test_duplicate_relationship_labels_rejected(self)
  test_schema_reports_wrong_order_without_exposing_values(self)
  test_xml_rejects_entities_and_malformed_documents(self)
  test_bare_mismo_message_is_not_a_service_request(self)
  test_schema_import_cannot_escape_root(self)
  test_schema_source_drift_is_rejected(self)
  test_business_rules_require_source_review(self)
  test_response_inspection_preserves_repeats_and_unknowns(self)
  test_upgrade_identical_is_no_change(self)
  test_synthetic_enum_change_identifies_affected_client_mapping(self)
  test_unmapped_and_table_changes_still_require_review(self)
  test_enum_table_change_traces_to_mapping_when_main_sheet_unchanged(self)
  test_cli_does_not_write_failed_request_and_saves_report(self)
  test_duplicate_json_keys_rejected(self)
  test_cli_reports_cannot_overwrite_inputs(self)
```

Local module dependencies:

- `lpa_tools.catalog: build_catalog, check_catalog, query`
- `lpa_tools.cli: main`
- `lpa_tools.common: LPAError, digest, file_hash, read_json, write_json`
- `lpa_tools.discovery: discover`
- `lpa_tools.mapping: check_profile, init_profile, render_request, resolve, scalar, MISSING`
- `lpa_tools.upgrade: compare_catalogs`
- `lpa_tools.xml_tools: NS, compile_schema, inspect_response, qname, secure_parse, validate_request`

## Verify

Each named case runs and checks its stated invariant. Include failures and recovery; full source and relocated suites pass without FM access.

Run the relevant checks in [ACCEPTANCE.md](../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `14739` bytes; SHA-256: `5355c2372bc6eda82d6102e6b62b381c9b0b575d87367bf75c246fc58a215cd7`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../FILE_INDEX.md)
