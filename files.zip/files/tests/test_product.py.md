# Rebuild `tests/test_product.py`

**Purpose:** Behavioral regression coverage for rule boundaries, assistance, handoff and bridges.

**Delivery role:** demo / regression verification. See [client delivery guidance](../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** Separately supplied native inputs plus generated synthetic fixtures; no live service. Resolve these through [INPUT_REFERENCES.md](../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Use unittest with temporary directories and actual local schema compilation where relevant. Recreate the named behavioral cases below, using positive and negative assertions on observable outputs/state/call counts.
2. Derive expected source constraints independently from the cited materials, not by calling the function under test to compute its own expected answer. Fake credentials and values only.
3. Block network connections in tests; preserve source bytes. Installed-package tests need paths based on unpacked fixtures/config rather than the original machine.
4. Keep main-suite cases and the pilot application tests distinct. A test count is a baseline inventory, not a substitute for meaningful assertions.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
class ProductTests(unittest.TestCase)
  setUpClass(cls)
  root(self)
  rule(self, root, name)
  test_response_fixtures_validate_and_replay_with_actual_response_schema(self)
  test_response_schema_drift_and_manifest_changes_fail_closed(self)
  test_unsupported_extension_fails_response_xsd(self)
  test_response_schema_rejects_wrong_element_order(self)
  test_ambiguous_status_does_not_choose_first(self)
  test_http_diagnostics_do_not_invent_root_cause(self)
  test_vendor_lookup_preserves_leading_zeroes_and_blank_combinations(self)
  test_asset_type_and_non_reo_value_presence(self)
  test_borrower_name_boundary_lengths_and_missing_names(self)
  test_alias_names_and_optional_phone_limits(self)
  test_semantic_owner_link_is_not_just_a_resolvable_label(self)
  test_sequence_missing_duplicate_and_scope(self)
  test_every_cardinality_rule_rejects_both_out_of_range_boundaries(self)
  test_subject_loan_property_and_marital_constraints(self)
  test_candidates_preserve_context_ambiguity_and_never_confirm(self)
  test_coverage_is_explicit_about_unmapped_requirements(self)
  handoff(self, directory, profile=None, responses=())
  test_handoff_contains_hash_checked_artifacts_and_response_reports(self)
  test_failed_handoff_does_not_emit_request_and_bad_response_is_not_success(self)
  test_generated_python_bridge_builds_and_analyzes_from_another_directory(self)
  test_codegen_preserves_existing_directory_and_requires_review(self)
  test_cli_rejects_bad_response_and_source_overwrite(self)
```

Local module dependencies:

- `lpa_tools.assistance: coverage, suggest_mappings`
- `lpa_tools.cli: main`
- `lpa_tools.codegen: generate_client`
- `lpa_tools.common: LPAError, digest, file_hash, read_json, write_json`
- `lpa_tools.handoff: build_handoff`
- `lpa_tools.mapping: render_request`
- `lpa_tools.responses: analyze_response, error_lookup`
- `lpa_tools.transactions: replay`
- `lpa_tools.vendors: query_vendors`
- `lpa_tools.xml_tools: NS, qname, secure_parse, compile_schema, compile_response_schema, evaluate_rules, validate_request`

## Verify

Each named case runs and checks its stated invariant. Include failures and recovery; full source and relocated suites pass without FM access.

Run the relevant checks in [ACCEPTANCE.md](../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `16725` bytes; SHA-256: `0f215d33f7cbb0546c2ad732035d6e3fd394f10e81f055e0e088a54b0280110c`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../FILE_INDEX.md)
