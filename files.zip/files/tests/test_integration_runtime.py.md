# Rebuild `tests/test_integration_runtime.py`

**Purpose:** Behavioral regression coverage for persistent client, mock, application demo and repository changes.

**Delivery role:** demo / regression verification. See [client delivery guidance](../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** Separately supplied native inputs plus generated synthetic fixtures; no live service. Resolve these through [INPUT_REFERENCES.md](../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Use unittest with temporary directories and actual local schema compilation where relevant. Recreate the named behavioral cases below, using positive and negative assertions on observable outputs/state/call counts.
2. Derive expected source constraints independently from the cited materials, not by calling the function under test to compute its own expected answer. Fake credentials and values only.
3. Block network connections in tests; preserve source bytes. Installed-package tests need paths based on unpacked fixtures/config rather than the original machine.
4. Keep main-suite cases and the pilot application tests distinct. A test count is a baseline inventory, not a substitute for meaningful assertions.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
class IntegrationTests(unittest.TestCase)
  setUpClass(cls)
  setUp(self)
  make_client(self, **overrides)
  submit(self)
  drain(self, report)
  test_complete_cycle_persists_results_and_refreshes_mock_tokens(self)
  test_duplicate_operation_and_interrupted_client_do_not_resubmit(self)
  test_before_due_poll_does_not_contact_transport(self)
  test_resubmission_serializes_persistent_identifiers(self)
  test_resubmission_without_reviewed_identifier_mapping_stops_before_transport(self)
  test_input_cannot_spoof_managed_identifiers(self)
  test_invalid_business_data_does_not_reach_service(self)
  test_mock_itself_checks_schema_auth_expiry_and_polling(self)
  test_non_200_stops_polling_and_keeps_loan_identifiers(self)
  test_unknown_delivery_blocks_automatic_and_new_submission(self)
  test_explicit_saved_response_reconciliation_recovers_unknown_delivery(self)
  test_changed_runtime_or_timing_policy_cannot_resume_pending_transaction(self)
  test_concurrent_state_write_is_rejected(self)
  test_transport_reentry_cannot_duplicate_an_in_flight_submission(self)
  test_identity_conflict_is_atomic_and_stops_polling(self)
  test_client_limits_leave_server_pending_transaction_unreplaced(self)
  test_blank_terminal_identifiers_do_not_erase_saved_ids(self)
  test_missing_or_implausible_interval_requires_review(self)
  test_credential_provider_failure_does_not_expose_secrets_or_contact_service(self)
  test_failed_credential_refresh_preserves_pending_remote_transaction(self)
  test_generated_python_bridge_runs_mock_assessment(self)
  test_feedback_is_allowlisted_not_regex_redaction_of_raw_logs(self)
  test_reference_application_is_patched_and_all_scenarios_exercised(self)
class RepositoryTests(unittest.TestCase)
  setUp(self)
  test_inventory_does_not_execute_source_or_include_secret_files(self)
  test_reviewable_patch_preserves_original_and_other_files(self)
  test_intervening_user_edit_rejects_entire_plan(self)
  test_traversal_and_symlink_destinations_are_rejected(self)
  test_failure_rolls_back_only_the_generated_changes(self)
  test_plan_is_bound_to_repository_and_cannot_be_modified_silently(self)
```

Local module dependencies:

- `lpa_tools.client: AssessmentClient, PollPolicy`
- `lpa_tools.common: LPAError, read_json, digest`
- `lpa_tools.feedback: export_feedback`
- `lpa_tools.mock_service: MockFMService, MockHeaderProvider, MockIdentityProvider, VirtualClock, response_xml, MOCK_HEADER`
- `lpa_tools.protocol: ASSESSMENTS, RESULTS, Request, Response, TransportFailure`
- `lpa_tools.repository: inspect_repository, plan_changes, apply_changes`
- `lpa_tools.runtime: Toolkit`
- `lpa_tools.state: StateStore`
- `lpa_tools.workflows: run_demo, run_mock`
- `lpa_tools.xml_tools: NS, secure_parse`

## Verify

Each named case runs and checks its stated invariant. Include failures and recovery; full source and relocated suites pass without FM access.

Run the relevant checks in [ACCEPTANCE.md](../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `16556` bytes; SHA-256: `a44d1eb9619a1a63b30c3fe7e022a04003e1669d00d6c505ef32e94ab709d778`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../FILE_INDEX.md)
