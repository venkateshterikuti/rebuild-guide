# Rebuild `tests/test_responses.py`

**Purpose:** Behavioral regression coverage for response interpretation and saved replay.

**Delivery role:** demo / regression verification. See [client delivery guidance](../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** Separately supplied native inputs plus generated synthetic fixtures; no live service. Resolve these through [INPUT_REFERENCES.md](../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Use unittest with temporary directories and actual local schema compilation where relevant. Recreate the named behavioral cases below, using positive and negative assertions on observable outputs/state/call counts.
2. Derive expected source constraints independently from the cited materials, not by calling the function under test to compute its own expected answer. Fake credentials and values only.
3. Block network connections in tests; preserve source bytes. Installed-package tests need paths based on unpacked fixtures/config rather than the original machine.
4. Keep main-suite cases and the pilot application tests distinct. A test count is a baseline inventory, not a substitute for meaningful assertions.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
class ResponseTests(unittest.TestCase)
  analyze(self, name='completed', **kwargs)
  test_reversed_deals_and_echoed_error_do_not_change_result(self)
  test_opt_in_values_and_unknown_error_preserved(self)
  test_non_xml_transport_failure_is_reported(self)
  test_namespace_spoof_cannot_create_processing_status(self)
  test_marker_discrepancy_is_not_silently_accepted(self)
  test_conflicting_statuses_require_review(self)
  test_partial_requires_valid_polling_fields(self)
  test_entity_document_rejected_without_network(self)
  test_future_feedback_code_and_unknown_nodes_retained(self)
  test_unknown_error_is_not_mislabeled_invalid(self)
class ReplayTests(unittest.TestCase)
  scenario(self)
  test_changing_intervals_completion_and_blank_id_preservation(self)
  test_early_retrieval_does_not_apply_saved_result(self)
  test_no_implicit_timing_unit(self)
  test_non_200_stops_retrieval_but_preserves_loan_id(self)
  test_identity_conflict_does_not_overwrite_state(self)
  test_changed_transaction_id_is_rejected(self)
  test_timezone_and_chronology_are_required(self)
```

Local module dependencies:

- `lpa_tools.common: LPAError, read_json`
- `lpa_tools.responses: analyze_response, error_lookup`
- `lpa_tools.transactions: replay`
- `lpa_tools.xml_tools: NS, secure_parse`

## Verify

Each named case runs and checks its stated invariant. Include failures and recovery; full source and relocated suites pass without FM access.

Run the relevant checks in [ACCEPTANCE.md](../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `7682` bytes; SHA-256: `616632d1879c26ab51a192e0ba48a1b35e521cce062ce2e61afbd8ab1ff4e27d`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../FILE_INDEX.md)
