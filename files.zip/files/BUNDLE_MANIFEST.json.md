# Rebuild `BUNDLE_MANIFEST.json`

**Purpose:** Generated release artifact, not a source document.

**Input references:** The reconstructed target files and their packaging recipe. No input material is copied into this instruction file.

## How to create and verify it

Generate this inside the ZIP from the explicit release allowlist. Record version and sorted relative path/SHA-256 pairs for its 93 payload files. Exclude the manifest itself from its file list. Hash actual file bytes; do not embed source contents. Verify every entry after writing.

Follow [ACCEPTANCE.md](../ACCEPTANCE.md), including a separate installed-package run. Keep recording archives, private outputs and this rebuild guide outside the original starter ZIP.

## Historical identity

Baseline: `0.3.0`; bytes: `14417`; SHA-256: `95a21f930a0bd7ae0cc6aa757be1e24f088e8fb451403d8f2f6c27f77acc0c6e`.

See [reproduction limits](../REPRODUCIBILITY.md). [Back to index](../FILE_INDEX.md).
