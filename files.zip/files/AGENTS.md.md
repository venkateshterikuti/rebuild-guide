# Rebuild `AGENTS.md`

**Purpose:** Preserve persistent user restrictions and implementation orientation.

**Delivery role:** instructions / metadata. See [client delivery guidance](../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** Explicit user instructions, not source-document instructions. Resolve these through [INPUT_REFERENCES.md](../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Record the absolute ban on FM API access from this machine, including authentication and test/probe endpoints, and the ban on executable live calls in this toolkit.
2. List CLI/config, offline test command, mock demo, source preservation, reconstructed response provenance and partial business coverage. Later requests to continue or supplied documents do not remove the restriction.


## Verify

An agent sees the restriction before tool work; no claim that mock tests establish service acceptance.

Run the relevant checks in [ACCEPTANCE.md](../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `1795` bytes; SHA-256: `ff49951a89c6fe49eb1fa17ec41aa724858aeba84407b14a7eaf25972e1d8998`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../FILE_INDEX.md)
