# Rebuild `lpa_tools/client.py`

**Purpose:** Manage a persistent assessment from reviewed input through polling and resubmission.

**Delivery role:** runtime / installation. See [client delivery guidance](../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** R3 for exchange/identity behavior; mapping/runtime/state design; mock choices explicitly separate. Resolve these through [INPUT_REFERENCES.md](../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. PollPolicy requires seconds/milliseconds plus a nonblank basis and positive finite local retrieval/time budgets. Validate returned interval and clock values. Pin toolkit/profile/policy into active transaction identity.
2. Submit requires a dictionary without reserved __lpa and a stable nonblank operation ID. Return the matching historical operation without another POST; reject the same ID with changed input. Block a new operation while any unresolved transaction is active; previous terminal history requires explicit resubmit.
3. Inject stored LPA/AUS IDs into reserved arrays, build/validate the request, and verify exactly one SubjectLoan serializes each known identifier before resubmission.
4. Save submitting/retrieving intent with revision checks before obtaining headers or delivering a request. Poll only pending transactions, enforce due time/current runtime/local budgets and percent-encode the saved async ID in the relative retrieval path.
5. A header failure before POST is credential_provider_error; before GET it is credential_refresh_error and must block a replacement POST. A transport exception gives submission_unknown/retrieval_unknown. Never retry POST automatically.
6. Analyze responses against the pinned XSD. Persist schema-valid results, sanitize event metadata, stop on non-200, require review for contract/identity conflicts, merge IDs atomically, update each Partial interval and remove polling details at terminal state.
7. Snapshots hide operation/async IDs, saved result values and loan IDs by default; explicit private snapshots expose stored results. Matching an older operation returns that operation, not the newest one.
8. Reconciliation applies an independently saved Response only to an interrupted/review state, requiring exact request hash, original runtime/policy and a nonblank human correlation basis. Store a digest of that review, not its text. Reconciliation itself makes no service call.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
class PollPolicy
  interval_unit: str
  basis: str
  max_retrievals: int
  max_elapsed_seconds: float
  __post_init__(self)
  seconds(self, interval)
class AssessmentClient
  __init__(self, toolkit, profile, transport, headers, clock, store, policy)
  now(self)
  snapshot(self, key, include_values=False, operation_id=None)
  submit(self, key, data, operation_id, *, resubmit=False)
  poll(self, key)
  _exchange(self, key, record, request, operation)
  reconcile(self, key, response, *, expected_request_sha256, correlation_review)
  _record_response(self, key, record, response, operation)
  _verify_resubmission_ids(xml, expected)
```

Local module dependencies:

- `.common: LPAError, digest`
- `.mapping: check_profile`
- `.protocol: ASSESSMENTS, RESULTS, Request, Response, TransportFailure`
- `.xml_tools: NS, secure_parse`

## Verify

Use the cases in tests/test_integration_runtime.py: duplicate/history/restart/concurrency/reentry, before-due polling, ID serialization, uncertain delivery/reconciliation, malformed/conflicting responses, local limits and failed credential refresh.

Run the relevant checks in [ACCEPTANCE.md](../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `14148` bytes; SHA-256: `1ae69feb1431fc37ea9237276f973aabe6976fb308d8a20a1d9f2a72d0ee9066`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../FILE_INDEX.md)
