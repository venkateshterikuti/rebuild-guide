# Rebuild `lpa_tools/workflows.py`

**Purpose:** Run real local mock cycles and integrate/test the reference application.

**Delivery role:** runtime / installation. See [client delivery guidance](../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** Pilot fixtures; runtime/client/mock/repository modules; R3-informed behavior with declared simulation settings. Resolve these through [INPUT_REFERENCES.md](../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. run_mock requires a fresh directory and reviewed profile; instantiate virtual time, mock credentials/service, private state and explicit client policy. Submit, advance virtual time to each due retrieval, and optionally explicitly resubmit after completion.
2. Write assessment, structured feedback, coverage, delivered request files, state database and artifact manifest. Record the mock assumptions and zero service acceptance evidence. Preserve fault states rather than forcing success.
3. run_demo copies the initially unconnected pilot, inventories it, saves mapping candidates, creates/applies five full-content changes, and runs original plus generated application tests in a subprocess with explicit config and installed-package support.
4. Then run all 11 scenarios and assert each expected final state. Create a separate synthetic target catalog, find the affected mapping, reject the stale profile and emit an unreviewed migration draft. Never mutate the real catalog.
5. Write linked README/summary and actual test output. Refuse existing output directories, do not run arbitrary repository code and never use a service network connection.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
run_mock(toolkit, profile, data, out, scenario='happy', resubmit=False)
run_demo(toolkit, out)
```

Local module dependencies:

- `.assistance: coverage, suggest_mappings`
- `.client: AssessmentClient, PollPolicy`
- `.common: LPAError, digest, file_hash, read_json, write_bytes, write_json`
- `.feedback: export_feedback`
- `.mapping: check_profile`
- `.mock_service: MockFMService, MockHeaderProvider, MockIdentityProvider, VirtualClock, SCENARIOS`
- `.repository: inspect_repository, plan_changes, apply_changes`
- `.state: StateStore`
- `.upgrade: compare_catalogs`

## Verify

Demo yields five real code/data/test changes, three passing application tests and eleven expected scenario states. Source fixture/catalog remain unchanged and installed templates work.

Run the relevant checks in [ACCEPTANCE.md](../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `9106` bytes; SHA-256: `e11a41c09109346ea8b720588392a6b092b5acbbb71acc7f8ebbf4e1e0c50f92`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../FILE_INDEX.md)
