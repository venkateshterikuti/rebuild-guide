# Rebuild `lpa_tools/__init__.py`

**Purpose:** Identify the package and baseline version.

**Delivery role:** runtime / installation. See [client delivery guidance](../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** Implementation release metadata. Resolve these through [INPUT_REFERENCES.md](../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Create a package docstring and expose __version__ as 0.3.0 for this baseline. Keep it consistent with pyproject.toml; change both for a separately identified future release.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
```

## Verify

Installed import returns the correct version without side effects.

Run the relevant checks in [ACCEPTANCE.md](../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `76` bytes; SHA-256: `6968e805f8cc21f3e6f24e0ee14e37f67c260b614a9f4347c55a5eaf4d1acb87`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../FILE_INDEX.md)
