# Rebuild `lpa_tools/catalog.py`

**Purpose:** Compile the native workbook into traceable scalar fields and retained source evidence.

**Delivery role:** runtime / installation. See [client delivery guidance](../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** R1, R2. Resolve these through [INPUT_REFERENCES.md](../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Read the workbook without saving it, preserving formulas, rich-text runs and font evidence. Validate the expected sheet/header layout before extraction.
2. Use the main requirements tab and six reference tabs identified in R1. Preserve populated main rows, cell addresses and relevant formatting; keep containers as evidence, not scalar mappings.
3. Map columns to sort ID, UID, path, parent, cardinality, term, definition, context, enums, conditions, business logic, format, notes, product applicability and form references. Read the precise headers from R1 rather than inventing labels.
4. A scalar field needs a UID, a MESSAGE-rooted context and a valid XML term; all-uppercase container terms do not become scalar fields. Use term-cell italic evidence or xlink prefix to infer attributes, with an explicit caveat that XSD is authoritative.
5. Create field keys from UID plus the first 12 hex characters of the canonical digest of path, term and kind. Reject duplicates. Fingerprint the native workbook and sorted relative XSD paths/hashes; hash the full catalog excluding its own ID.
6. Query case-insensitively by UID or key/term/path/context/definition. Validate catalog identity before use.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
text_value(value)
font_evidence(font)
cell_evidence(cell)
schema_manifest(schema_root)
build_catalog(workbook, schema_root, release='6.1.00')
check_catalog(catalog)
query(catalog, search)
```

Local module dependencies:

- `.common: LPAError, digest, file_hash`

## Verify

The supplied baseline yields 404 scalar fields, 858 populated main rows and six reference tables. Rebuilding from unchanged inputs must reproduce catalog identity; source typography and duplicate identities have regression cases.

Run the relevant checks in [ACCEPTANCE.md](../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `6124` bytes; SHA-256: `838a04df40e60939b97e21d500813034c6d9f196018d4cf98690ec7cddf4c457`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../FILE_INDEX.md)
