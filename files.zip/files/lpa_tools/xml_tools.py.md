# Rebuild `lpa_tools/xml_tools.py`

**Purpose:** Confined local XSD validation and selected deterministic business checks.

**Delivery role:** runtime / installation. See [client delivery guidance](../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** R1, R2, R4, R5. Resolve these through [INPUT_REFERENCES.md](../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Use exact namespace-qualified names obtained from supplied schemas. XML parsing has a 20 MiB limit, DTD/entity expansion disabled and no network resolution.
2. Confine schema imports to the configured local root, reject remote schemes/netlocs and paths escaping it, and check source fingerprints before compiling. Response compilation separately pins its manifest and actual XSD tree.
3. Execute the six implemented rule families: allowed values, XPath assertion, container occurrence count, xlink integrity, asset ownership and sibling sequence uniqueness. Only accept known families and a reviewed catalog pin.
4. Resolve relationship labels in their containing scope. Require unique endpoints/arcrole. Separately verify eligible assets link to Borrower roles and require eligible-asset coverage for multi-borrower cases; use R1 to determine exclusions.
5. Run XSD before business checks. Report codes/locations instead of parser messages that may contain borrower values. Keep not-run, not-applicable, failed and partial-pass distinct; always retain submission_ready=false.
6. Provide structural response inventory as an explicitly uninterpreted operation with values omitted unless requested.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
qname(name, attribute=False)
secure_parse(data)
class LocalSchemas(etree.Resolver)
  __init__(self, root)
  resolve(self, url, pubid, context)
compile_schema(schema_root, entry, catalog=None)
compile_response_schema(schema_root, manifest_path, expected_id)
relationship_issues(root)
asset_ownership_issues(root)
evaluate_rules(root, ruleset, catalog)
validate_request(data, schema, catalog, ruleset=None)
inspect_response(data, include_values=False)
```

Local module dependencies:

- `.catalog: check_catalog, schema_manifest`
- `.common: LPAError, read_json, digest`

## Verify

Reject namespace spoofing, malformed/DTD/entity XML, remote/traversing imports and source drift. Test rule boundaries, ownership direction/role, duplicate sibling sequences and diagnostics without sample values.

Run the relevant checks in [ACCEPTANCE.md](../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `12617` bytes; SHA-256: `cc14e4e63513b1198dbac749ad3b0bd219cee76b4752fda14467058683f513f2`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../FILE_INDEX.md)
