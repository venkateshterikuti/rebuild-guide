# Rebuild `lpa_tools/protocol.py`

**Purpose:** Define injectable transport/header/clock contracts without a network connector.

**Delivery role:** runtime / installation. See [client delivery guidance](../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** R3 sections IV.C.1 and IV.C.4 for relative paths; implementation design for interfaces. Resolve these through [INPUT_REFERENCES.md](../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Define immutable Request(method, path, headers, body) and Response(status, body). Exclude headers/body from repr. Define TransportFailure to denote uncertain delivery.
2. Expose Transport.exchange, HeaderProvider.headers and Clock.now protocols. Obtain the two relative submit/retrieve paths from R3; do not add hosts, an endpoint switch or executable HTTP calls.
3. The mock and future separately implemented client-environment adapter can satisfy these interfaces; a protocol is not itself that adapter.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
class Request
  method: str
  path: str
  headers: dict[str, str]
  body: bytes
class Response
  status: int
  body: bytes
class TransportFailure(Exception)
class Transport(Protocol)
  exchange(self, request: Request)
class HeaderProvider(Protocol)
  headers(self, now: float)
class Clock(Protocol)
  now(self)
```

## Verify

Requests carry relative paths and bytes; repr does not expose tokens or XML; both mock and application client use these interfaces.

Run the relevant checks in [ACCEPTANCE.md](../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `1064` bytes; SHA-256: `d11599e311632bb81783562c032dbeafa48553549550f6595286171907734012`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../FILE_INDEX.md)
