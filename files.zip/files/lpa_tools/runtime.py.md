# Rebuild `lpa_tools/runtime.py`

**Purpose:** Load one pinned specification runtime for CLI and application clients.

**Delivery role:** runtime / installation. See [client delivery guidance](../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** Configuration plus R1/R2-derived catalog/rules and reconstructed response tree. Resolve these through [INPUT_REFERENCES.md](../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Resolve configuration to an absolute path, then load referenced files relative to it. Compile request and response schemas independently with their pin checks.
2. Compute runtime identity from catalog ID, rule digest and response manifest ID. Build validates the reviewed profile, renders XML, and returns XML only on selected-check success with its report.
3. Expose validate and analyze wrappers; response analysis includes the configured response schema ID. Do not require extraction archives at runtime.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
class Toolkit
  __init__(self, config_path)
  build(self, data, profile)
  validate(self, xml)
  analyze(self, xml, http_status=200, include_values=False)
```

Local module dependencies:

- `.common: LPAError, read_json, digest`
- `.mapping: render_request, check_profile`
- `.responses: analyze_response`
- `.xml_tools: compile_schema, compile_response_schema, validate_request`

## Verify

Run from an unrelated directory using an absolute config path; schema drift fails; bad business data yields no transport-ready XML.

Run the relevant checks in [ACCEPTANCE.md](../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `1826` bytes; SHA-256: `c2873e39385fa635d8d0d188d56a2584897a2e5d20975ad54a26dc16e5f4d751`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../FILE_INDEX.md)
