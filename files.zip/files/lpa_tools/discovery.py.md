# Rebuild `lpa_tools/discovery.py`

**Purpose:** Inventory a JSON sample without disclosing sample values.

**Delivery role:** runtime / installation. See [client delivery guidance](../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** Client JSON input; synthetic samples are generated tool fixtures. Resolve these through [INPUT_REFERENCES.md](../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Recursively visit objects, arrays and scalars. Escape JSON Pointer segments, start at $, and aggregate array positions as /*.
2. Record observed types and counts for every path, distinguishing booleans from integers and null from missing data. Sort results for deterministic output.
3. Do not include raw values or infer optionality from absent sample fields.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
discover(data)
```

## Verify

Repeated arrays aggregate correctly; pointer escaping and mixed types are retained; borrower values never appear in the report.

Run the relevant checks in [ACCEPTANCE.md](../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `1162` bytes; SHA-256: `cd74b4a1182c16ebefc91a4a1fa0927bac12ee8c9714f9cc314519184c6d96de`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../FILE_INDEX.md)
