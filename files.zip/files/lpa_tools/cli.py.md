# Rebuild `lpa_tools/cli.py`

**Purpose:** Expose the deterministic local toolkit as a JSON-reporting CLI.

**Delivery role:** runtime / installation. See [client delivery guidance](../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** All implemented modules; configuration and artifact contracts. Resolve these through [INPUT_REFERENCES.md](../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Use argparse with --config defaulting to lpa-project.json. Source paths resolve relative to config; user input/output paths relative to the working directory.
2. Expose catalog-build/query, discover, profile-init/check, request-build, validate, response-inspect/analyze, error-explain, vendor-query, transaction-replay, map-suggest, coverage, handoff, client-generate, upgrade, repo-inspect/plan/apply, mock-run, demo and feedback-export.
3. Preserve command-specific fresh-directory/input-output collision checks and protect configured native inputs/catalog/reference/schema files. Commands not requiring config should run independently.
4. Print structured JSON and exit 0 for success, 2 for failures/review where specified. Failed request generation preserves existing XML and marks request_written false. Successful validation still retains submission_ready false.
5. Catch expected LPA errors distinctly; sanitize parser, filesystem, database, subprocess-timeout and malformed-input exceptions to avoid echoing sensitive content. No automatic network probes.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
protect_inputs(outputs, inputs)
parser()
run(args)
main(argv=None)
```

Local module dependencies:

- `.catalog: build_catalog, query`
- `.common: LPAError, digest, read_json, write_bytes, write_json`
- `.discovery: discover`
- `.mapping: check_profile, init_profile, render_request`
- `.upgrade: compare_catalogs`
- `.xml_tools: compile_schema, compile_response_schema, inspect_response, validate_request`
- `.responses: analyze_response, error_lookup`
- `.transactions: replay`
- `.assistance: suggest_mappings, coverage`
- `.handoff: build_handoff`
- `.codegen: generate_client`
- `.vendors: query_vendors`
- `.repository: inspect_repository, plan_changes, apply_changes`
- `.feedback: export_feedback`

## Verify

Exercise argument parsing, bad responses, source/output collisions, failed-output preservation, mock expected faults and package execution from unrelated working directories.

Run the relevant checks in [ACCEPTANCE.md](../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `15484` bytes; SHA-256: `996de948c9a7439bb1c93e08cab7f33b8e3176672374c4aa2d1862b030389210`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../FILE_INDEX.md)
