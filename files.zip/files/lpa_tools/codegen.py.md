# Rebuild `lpa_tools/codegen.py`

**Purpose:** Generate language bridges around one installed Python runtime.

**Delivery role:** runtime / installation. See [client delivery guidance](../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** Tool interfaces and reviewed profile; no additional domain source. Resolve these through [INPUT_REFERENCES.md](../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Validate profile/language and require a fresh destination. Load templates via importlib.resources so installation and relocation work.
2. Generate Python, Java or C# bridge source, the C# project when needed, adjacent profile, usage README and hash manifest.
3. Document build, response, replay and mock operations, exit codes, Python dependency and offline boundary. These bridges do not implement live HTTP/OAuth.
4. Use argument arrays and explicit Python/config paths. Java/C# profile lookup uses their scaffold working directory; Python resolves it beside its script.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
generate_client(language, profile, catalog, out)
```

Local module dependencies:

- `.common: LPAError, digest, file_hash, write_bytes, write_json`
- `.mapping: check_profile`

## Verify

Execute Python build/analyze/mock from another directory with spaces; generate all templates after package installation; report Java/C# compilation as unverified unless actually run.

Run the relevant checks in [ACCEPTANCE.md](../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `3813` bytes; SHA-256: `d46bde54f9a9ebd13badac54a71b57d912e8d4ef7ac2af2bac9f526bdda119e9`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../FILE_INDEX.md)
