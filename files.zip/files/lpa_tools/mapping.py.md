# Rebuild `lpa_tools/mapping.py`

**Purpose:** Render reviewed semantic mappings into ordered XML.

**Delivery role:** runtime / installation. See [client delivery guidance](../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** R1, R2, R9 where applicable; reviewed client meanings. Resolve these through [INPUT_REFERENCES.md](../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Implement $ root and @ current-repeat JSON pointers with proper escape validation and an explicit missing sentinel. Support identity, enum and decimal2 transformations only; reject null/containers/non-finite values, unknown enum keys and precision loss.
2. A profile pins the catalog and requires confirmed scope, no unresolved decisions, and confirmed mappings with a reason and exactly one source or constant. Missing-value policy is error or omit; explicit null does not become missing.
3. Validate every mapping against its catalog context and element/attribute kind. Reject stale catalogs, wrong contexts, unused mappings and unrecognized template properties.
4. Represent XML as ordered nodes with tag, optional repeat, text binding, attributes and children. Direct noncatalog bindings are limited to reviewed xlink/sequence structure. Require one nonrepeated MESSAGE root.
5. For each repeat use its own current object; do not zip arrays or infer asset ownership by position. Bind values before emitting optional elements. Wrap the result in the request envelope defined by R2 using namespaces from supplied schemas. Never eval template data.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
resolve(pointer, root, current)
scalar(value, transform='identity', enum_map=None)
init_profile(client_id, catalog)
check_profile(profile, catalog)
render_request(data, profile, catalog)
```

Local module dependencies:

- `.catalog: check_catalog`
- `.common: LPAError`
- `.xml_tools: NS, qname`

## Verify

Exercise stale/unreviewed profiles, wrong paths, nested repeats, null/missing/zero/false, escaped pointers, unknown enum/transform, extra precision and proper ownership.

Run the relevant checks in [ACCEPTANCE.md](../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `8804` bytes; SHA-256: `b25dc6c899d95885cc22052c6e05667725d4aa05150a5ffaaac45e71e30e7b2e`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../FILE_INDEX.md)
