# Rebuild `lpa_tools/state.py`

**Purpose:** Persist private loan/transaction state with revision checks.

**Delivery role:** runtime / installation. See [client delivery guidance](../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** Implementation design; no domain-source contents. Resolve these through [INPUT_REFERENCES.md](../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Create an owner-only SQLite file and private parent directory; reject a symlink state file. Store loan_key primary key, revision and JSON record.
2. Use connection context management that commits/rolls back and always closes. New keys return revision 0, empty IDs and transaction history.
3. Validate nonblank keys on read. Put uses BEGIN IMMEDIATE and compare-and-swap expected revision; write an incremented revision with JSON allowing no non-finite values.
4. Persist application state/results; do not add payload/header/token logging. Local operation-ID protection is not remote idempotency.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
class StateStore
  __init__(self, path)
  connect(self)
  get(self, key)
  put(self, key, record, expected_revision)
```

Local module dependencies:

- `.common: LPAError`

## Verify

State survives a new client/store instance; stale concurrent writes fail; intent is saved before transport; tokens are absent from the database.

Run the relevant checks in [ACCEPTANCE.md](../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `2029` bytes; SHA-256: `b0dc10b9f50c8a851249403f67bb9876e736e4f4dd90ab99d877c317c8b9b1bd`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../FILE_INDEX.md)
