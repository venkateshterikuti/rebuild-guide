# Rebuild `lpa_tools/upgrade.py`

**Purpose:** Review catalog changes without automatically approving migration.

**Delivery role:** runtime / installation. See [client delivery guidance](../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** Separate baseline/target catalogs derived from R1/R2; R8 only as context. Resolve these through [INPUT_REFERENCES.md](../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Validate both catalog identities and require any profile to pin the baseline. Compare stable field keys; report additions/removals/property changes and before/after evidence while ignoring only location/sort/inference metadata for semantic field comparison.
2. Independently flag XSD tree, reference-table and raw-workbook-evidence changes. Group supported-enum evidence by UID to connect changes to mappings.
3. Return affected mapping names and their supplied code locations. Highlight required/conditional target rows even when unmapped. Identical catalog returns identical_catalog; other changes require review.
4. Do not mutate a client profile or treat an empty affected list as proof of compatibility.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
enum_evidence(catalog)
compare_catalogs(baseline, target, profile=None)
```

Local module dependencies:

- `.catalog: check_catalog`
- `.common: LPAError`

## Verify

Unchanged catalog, changed context/enum/source evidence, added conditional field, stale profile and code-location impact must all be exercised. Synthetic release changes are labeled.

Run the relevant checks in [ACCEPTANCE.md](../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `4166` bytes; SHA-256: `abf8444b622265a2619b305b0bae1d5be895d6c571d6cb42cbeee1369cc02eed`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../FILE_INDEX.md)
