# Rebuild `lpa_tools/vendors.py`

**Purpose:** Look up recorded vendor combinations without inventing eligibility.

**Delivery role:** runtime / installation. See [client delivery guidance](../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** R6 and optional D3. Resolve these through [INPUT_REFERENCES.md](../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Require reference format 1 and a nonblank query. Search names case-insensitively or codes exactly across CRC product columns and affiliate codes.
2. Return recorded rows with their provenance, blank-cell meaning and limitations. Preserve string codes and product distinctions. Never concatenate codes to invent combinations or infer current effective dates.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
query_vendors(reference, search)
```

Local module dependencies:

- `.common: LPAError`

## Verify

Leading-zero codes and null cells survive lookup; partial name matching works; operational validity remains unestablished.

Run the relevant checks in [ACCEPTANCE.md](../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `1192` bytes; SHA-256: `a0180bd3b36099404a4fdba4ca2f904a8574ea594f5da9260922e591f7ca945e`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../FILE_INDEX.md)
