# Rebuild `lpa_tools/repository.py`

**Purpose:** Inspect repositories and apply reviewable, hash-checked changes.

**Delivery role:** runtime / installation. See [client delivery guidance](../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** Authorized client repository, or the fabricated pilot; implementation design. Resolve these through [INPUT_REFERENCES.md](../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Inventory supported text/code files without execution, skipping hidden/build/dependency/cache directories and symlinks. Cap at 2000 files and 1 MiB each; report truncation. Use Python AST for top-level functions/classes and provide nonexecuted test-command candidates.
2. Plan accepts 1–100 relative path/full-content changes. Confine paths to repository; reject traversal, symlink components, unsafe suffixes and secret-environment filenames. Normalize names and reject duplicates.
3. Record old/new content hashes, original text/mode, a unified diff, repository identity and whole-plan digest. Skip no-ops; reject an empty plan.
4. Apply validates all content/pins before writing, takes an exclusive lock, rechecks each destination and writes atomically while preserving mode. On failure roll back only own unchanged writes and preserve concurrent edits. Remove the lock in cleanup.
5. Plan hashes detect drift, not trustworthiness of its author. Do not execute changed files or arbitrary discovered tests during application.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
safe_path(root, name)
inspect_repository(root)
plan_changes(root, changes)
apply_changes(root, plan)
```

Local module dependencies:

- `.common: LPAError, digest, file_hash, write_bytes`

## Verify

Inventory malicious-looking code without executing it. Test traversal, symlink, stale-plan/tamper rejection, original-code preservation and write-failure rollback.

Run the relevant checks in [ACCEPTANCE.md](../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `7755` bytes; SHA-256: `9c1672278899e46579c2fd3ef18f71d1983d3d752b2efa89fee38816b893d83e`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../FILE_INDEX.md)
