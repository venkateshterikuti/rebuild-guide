# Rebuild `lpa_tools/assistance.py`

**Purpose:** Conservative candidate ranking and honest coverage reports.

**Delivery role:** runtime / installation. See [client delivery guidance](../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** R1-derived catalog and reviewed rules; client sample structure. Resolve these through [INPUT_REFERENCES.md](../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Tokenize camelCase and lowercase alphanumerics. Rank intersecting name tokens with 100 for an exact token-set match plus rounded 50 times token-set overlap/union; stable sort by score then field key. Candidate limit is 1–20.
2. Skip object/array/null-only fields. Return context, source locations and the fact that scores use names only. Never create or confirm a profile.
3. Coverage maps rule source sheet/rows to catalog fields and lists saved mappings, selected checks, unimplemented requirements and applicability review. Require catalog pins. Never infer completeness from a percentage or mapping count.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
tokens(value)
suggest_mappings(data, catalog, limit=5)
coverage(catalog, ruleset, profile=None)
```

Local module dependencies:

- `.catalog: check_catalog`
- `.common: LPAError`
- `.discovery: discover`

## Verify

Ambiguous borrower/alias contexts remain separate and unreviewed; mapped fields with no rules remain uncovered; a cited rule does not imply the whole row is implemented.

Run the relevant checks in [ACCEPTANCE.md](../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `4113` bytes; SHA-256: `6b04976914bc0337008dcc59053bdd54e3de26b85f49cb651a1e3588e2d4b062`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../FILE_INDEX.md)
