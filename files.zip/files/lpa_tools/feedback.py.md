# Rebuild `lpa_tools/feedback.py`

**Purpose:** Export narrowly allowlisted runtime diagnostics for user feedback.

**Delivery role:** runtime / installation. See [client delivery guidance](../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** Runtime report contract; partial diagnostic-code reference only. Resolve these through [INPUT_REFERENCES.md](../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Accept known structured assessment states only; reject arbitrary raw-log objects. Include format, toolkit version, states and approved operation/HTTP/schema/processing fields.
2. Keep known-format processing codes; hash unknown code strings. Preserve allowlisted issue identifiers and hash unrecognized issue strings. Drop all other supplied fields, including headers, raw XML, identifiers and payloads.
3. Do not transmit files or claim generic raw-log redaction. Keep a limitation statement and require the user to review the local artifact before sharing.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
export_feedback(report)
```

Local module dependencies:

- `.common: LPAError`
- `.: __version__`

## Verify

Inject private strings in extra keys, codes, issues, headers and raw bodies: none appear verbatim in exported JSON. Credential-refresh failure is an accepted state.

Run the relevant checks in [ACCEPTANCE.md](../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `3344` bytes; SHA-256: `bb18402c5762c99f6ec7b7550de7b08d2d280a31889295b3681a89d921656519`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../FILE_INDEX.md)
