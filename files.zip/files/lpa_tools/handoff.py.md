# Rebuild `lpa_tools/handoff.py`

**Purpose:** Build a reviewable local client delivery.

**Delivery role:** runtime / installation. See [client delivery guidance](../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** Generated profile/data plus local validation and optional saved responses/catalog baseline. Resolve these through [INPUT_REFERENCES.md](../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Require a fresh directory. Assemble discovery, saved profile, coverage, profile check and validation before delivery. Catch expected profile/render errors into a blocked report.
2. Write request XML only if implemented checks pass. Saved-response review can make the overall delivery review_required even when request generation passes.
3. Optionally include response reports and global baseline-to-target changes. Generate a linked README and manifest of artifact byte hashes, plus input/profile/rules identities.
4. Keep request values local and retain partial coverage. A manifest is a drift check, not a signature.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
build_handoff(data, profile, catalog, ruleset, schema, out, reference, responses=(), baseline=None, response_schema=None)
```

Local module dependencies:

- `.assistance: coverage`
- `.common: LPAError, digest, file_hash, write_bytes, write_json`
- `.discovery: discover`
- `.mapping: check_profile, render_request`
- `.responses: analyze_response`
- `.upgrade: compare_catalogs`
- `.xml_tools: validate_request`

## Verify

Every delivered artifact hash resolves; failure emits no new request; an existing delivery is preserved; an invalid response prevents a false overall success.

Run the relevant checks in [ACCEPTANCE.md](../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `4853` bytes; SHA-256: `c90b719d24b9d4a07a703af6d12f1acd254b23254c4e592e056578708ef66993`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../FILE_INDEX.md)
