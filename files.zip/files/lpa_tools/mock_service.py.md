# Rebuild `lpa_tools/mock_service.py`

**Purpose:** Simulate a document-shaped service entirely in process.

**Delivery role:** runtime / installation. See [client delivery guidance](../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** R2/R3/R4/R5 for structure and checked paths; simulation assumptions for authentication/timing/results. Resolve these through [INPUT_REFERENCES.md](../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Implement VirtualClock, a mock token issuer with expiry, and a header provider that refreshes before use. Declare token header/lifetime as fake test choices.
2. Accept only relative documented paths and appropriate methods. Validate mock credentials and the request XSD/selected rules independently before creating an assessment.
3. Assign stable synthetic loan/AUS IDs, fresh transaction IDs, preserve request echo and produce response-first DEAL ordering to exercise marker selection. Validate responses using the separate wrapper; underwriting text must say it is synthetic.
4. Initial and subsequent Partial responses use changing intervals. Reject early retrieval and unknown/conflicting identifiers. Completion returns a synthetic result; explicit resubmission retains loan identity.
5. Provide happy, processing_error, http_400, unauthorized, rate_limit, server_error, malformed, timeout_submit, timeout_get, identifier_conflict and partial_forever scenarios. Timeout-submit occurs after mock acceptance to test uncertain delivery.
6. Keep call metadata separate from test-only delivered request bodies. No sockets, listener, HTTP client, real token grant or base-URL flag.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
class VirtualClock
  __init__(self, start=0.0)
  now(self)
  advance(self, seconds)
class MockIdentityProvider
  __init__(self, ttl=20)
  issue(self, now)
  accepts(self, headers, now)
class MockHeaderProvider
  __init__(self, identity)
  headers(self, now)
element(parent, tag, text=None, **attrs)
response_xml(status, identifiers=None, async_id=None, interval=None, errors=(), echo=None)
class MockFMService
  __init__(self, toolkit, identity, clock, scenario='happy', intervals=(15, 30))
  exchange(self, request)
  _error(self, http, code)
  _submit(self, body)
  _retrieve(self, async_id)
```

Local module dependencies:

- `.common: LPAError`
- `.protocol: ASSESSMENTS, RESULTS, Request, Response, TransportFailure`
- `.responses: RESPONSE_ROOT`
- `.xml_tools: NS, qname, secure_parse`

## Verify

Check standalone mock credential expiry, request rejection, early polling and stable IDs. All 11 client scenario outcomes must match expected states without network access.

Run the relevant checks in [ACCEPTANCE.md](../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `9966` bytes; SHA-256: `64c22b3088ce4257e27f5342c240ac8a9a8c2a42bcabc13e2a51f75cfd79f80a`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../FILE_INDEX.md)
