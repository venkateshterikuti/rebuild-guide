# Rebuild `lpa_tools/responses.py`

**Purpose:** Interpret saved response envelopes with explicit uncertainty.

**Delivery role:** runtime / installation. See [client delivery guidance](../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** R3 sections IV and V; R4/R5 response schema; R7 partial error export. Resolve these through [INPUT_REFERENCES.md](../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Validate integer HTTP status and hash response bytes. Keep transport, schema, processing and underwriting outcomes separate. Parse with the shared secure parser and exact response namespace/root from the sources.
2. Require one MESSAGE and locate DEAL meaning using the documented marker, not array order. The source has conflicting alternate marker wording; preserve that discrepancy and require review instead of normalizing it silently.
3. Validate against the separate response XSD when provided. Inventory unknown nodes. Extract processing statuses, repeated errors, opaque feedback codes and loan-scoped identifiers only from the response DEAL.
4. Select status fields without silently choosing the first ambiguous one. Partial needs exactly one usable async ID and a finite positive interval; terminal polling fields and completed-with-errors require review. Do not infer the interval unit.
5. Default reports omit loan/result/error-text values but keep diagnostic code references; explicit include_values returns private values. Unknown codes are not automatically invalid. HTTP lookup names possible components, not a unique cause.
6. Use R3 to locate exact loan ID, polling, feedback and error paths; do not derive those paths from local-name matching or the unverified response-field export.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
nodes(node, path)
text(node, path)
error_lookup(reference, code)
analyze_response(data, reference, http_status=200, include_values=False, schema=None)
```

Local module dependencies:

- `.common: LPAError`
- `.xml_tools: NS, qname, secure_parse`

## Verify

Reverse DEALs, spoof namespaces, echo an error, omit/conflict status, supply invalid polling, blank IDs or unknown/future feedback, and validate both default/private reports.

Run the relevant checks in [ACCEPTANCE.md](../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `11522` bytes; SHA-256: `ca337bcfeee1f5197dd5c7ab3ac7e1704026295937b6821f8e3e23279ac87fde`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../FILE_INDEX.md)
