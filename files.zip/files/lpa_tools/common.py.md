# Rebuild `lpa_tools/common.py`

**Purpose:** Deterministic JSON identity and safe local artifact I/O.

**Delivery role:** runtime / installation. See [client delivery guidance](../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** Implementation design; no domain-source text. Resolve these through [INPUT_REFERENCES.md](../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Define LPAError as a ValueError subtype. Canonical digest is SHA-256 of UTF-8 JSON with sorted keys, compact separators, Unicode retained and non-finite numbers rejected.
2. Hash files in chunks. Reject duplicate JSON object keys and NaN/Infinity on read.
3. Write bytes through a temporary file in the destination directory, flush/fsync and atomically replace. Clean temporary files on failure; create private files. Pretty JSON uses two-space indentation and a trailing newline.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
class LPAError(ValueError)
digest(value)
file_hash(path)
read_json(path)
write_bytes(path, data)
write_json(path, value)
```

## Verify

Duplicate/non-finite JSON must fail; the same value must hash identically across key insertion order; failed writes must not leave truncated outputs.

Run the relevant checks in [ACCEPTANCE.md](../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `1657` bytes; SHA-256: `eb909b7a89eb182dbd24cea9e8d08163dcbf3db164341f078ded237e3aa5fcac`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../FILE_INDEX.md)
