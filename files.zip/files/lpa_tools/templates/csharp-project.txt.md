# Rebuild `lpa_tools/templates/csharp-project.txt`

**Purpose:** Minimal build project for the C# CLI bridge.

**Delivery role:** generation templates. See [client delivery guidance](../../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** Implementation toolchain choice. Resolve these through [INPUT_REFERENCES.md](../../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Generate an SDK-style executable .NET 8 project with implicit usings and nullable support for the bridge. No network SDK package dependency or real FM credentials.


## Verify

Generated project/source are compatible; compilation remains unclaimed unless actually run.

Run the relevant checks in [ACCEPTANCE.md](../../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `237` bytes; SHA-256: `031da6a6f6d810b9f23ffe7818f3acefb7b0ff54b0eb8c6752735ad58d254904`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../../FILE_INDEX.md)
