# Rebuild `lpa_tools/templates/integration-python.txt`

**Purpose:** Application adapter around the persistent assessment client.

**Delivery role:** generation templates. See [client delivery guidance](../../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** Runtime/client/state interfaces; reviewed pilot profile. Resolve these through [INPUT_REFERENCES.md](../../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Define LoanIntegration taking config, state path, injected transport, header provider, clock and policy. Load lpa_profile.json next to the generated adapter.
2. Construct Toolkit, StateStore and AssessmentClient. submit maps application_id and submission_id and an explicit optional resubmission flag; poll and result delegate with values omitted by default.
3. Keep networking and credential acquisition outside this template. Explain the live boundary and guide location in its docstring.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
class LoanIntegration
  __init__(self, config, state_path, transport, header_provider, clock, policy)
  submit(self, application)
  poll(self, application_id)
  result(self, application_id, include_values=False)
```

Local module dependencies:

- `lpa_tools.client: AssessmentClient, PollPolicy`
- `lpa_tools.common: read_json`
- `lpa_tools.runtime: Toolkit`
- `lpa_tools.state: StateStore`

## Verify

The generated application calls this adapter and retrieves stored results; injected mock tests work without any endpoint configuration.

Run the relevant checks in [ACCEPTANCE.md](../../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `1230` bytes; SHA-256: `41519d8b67dbd853e66c923954df26ffebaf612e46e2625265d3938cf7c152ad`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../../FILE_INDEX.md)
