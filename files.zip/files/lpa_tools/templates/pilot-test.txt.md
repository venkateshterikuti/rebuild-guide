# Rebuild `lpa_tools/templates/pilot-test.txt`

**Purpose:** Integration test inserted into the sample application.

**Delivery role:** generation templates. See [client delivery guidance](../../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** Synthetic pilot app and mock/client contracts. Resolve these through [INPUT_REFERENCES.md](../../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Create the mock dependencies, virtual clock and explicit simulation policy using LPA_TOOLKIT_CONFIG. Use a fresh private state path and block socket connections.
2. Exercise the application assess action, duplicate submission, changing polling intervals until completion, preservation of original draft behavior and explicit resubmission with the same loan identity.
3. Assert actual calls/token refresh and partial-readiness signal. The test must execute the adapter, not merely inspect generated text.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
class ApplicationIntegrationTests(unittest.TestCase)
  test_application_submission_polling_resubmission_and_existing_behavior(self)
```

Local module dependencies:

- `lpa_tools.client: PollPolicy`
- `lpa_tools.mock_service: MockFMService, MockHeaderProvider, MockIdentityProvider, VirtualClock`
- `lpa_tools.runtime: Toolkit`

## Verify

The demo runs this test alongside two original tests; the three tests pass through the installed runtime as well.

Run the relevant checks in [ACCEPTANCE.md](../../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `2141` bytes; SHA-256: `6a168713b83908de420bac8bb9df2f6ea69f3b6d356667929c1d3eefeda8d8b0`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../../FILE_INDEX.md)
