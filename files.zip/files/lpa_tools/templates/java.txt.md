# Rebuild `lpa_tools/templates/java.txt`

**Purpose:** Java local CLI bridge template.

**Delivery role:** generation templates. See [client delivery guidance](../../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** Tool CLI contracts, not FM authentication/transport documentation. Resolve these through [INPUT_REFERENCES.md](../../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Accept Python executable, toolkit config, operation and operation arguments. Build subprocess arguments as an array with no shell.
2. Route build to request-build with adjacent profile; response to response-analyze with HTTP status; replay to transaction-replay; mock to mock-run. Propagate child exit status and sanitize launch errors.
3. Python resolves its profile beside the generated file; Java/C# require scaffold-directory working context. Java uses Java 11+ source-file mode; C# targets .NET 8. Do not add live networking or automatic toolchain downloads.


## Verify

Generate with installed resources. Python runs all supported operations; compile other languages only when their toolchains exist and record actual results.

Run the relevant checks in [ACCEPTANCE.md](../../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `2150` bytes; SHA-256: `df72617bbf6377c33851d3379f5482315429a60822b5de762492c7be35dd5f80`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../../FILE_INDEX.md)
