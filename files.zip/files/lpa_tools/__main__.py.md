# Rebuild `lpa_tools/__main__.py`

**Purpose:** Support python -m lpa_tools.

**Delivery role:** runtime / installation. See [client delivery guidance](../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** cli.py entry point. Resolve these through [INPUT_REFERENCES.md](../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Import main from the CLI module and exit with its returned code. Do not run unrelated initialization or environment probes.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
```

Local module dependencies:

- `.cli: main`

## Verify

Module and installed lpa entry point have the same JSON output and exit semantics.

Run the relevant checks in [ACCEPTANCE.md](../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `48` bytes; SHA-256: `935a1c1166b0c1ea35a82256345000bf2c73ded718d77773bc27a71ecce28f7d`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../FILE_INDEX.md)
