# Rebuild `lpa_tools/transactions.py`

**Purpose:** Replay saved exchanges without transport or wall-clock waiting.

**Delivery role:** runtime / installation. See [client delivery guidance](../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** R3; local response fixtures and scenario definition. Resolve these through [INPUT_REFERENCES.md](../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Accept scenario format 1 and 1–1000 saved events; this cap is a local resource limit. Require submit/retrieve operations and timezone-aware chronological timestamps.
2. Timing units are absent, seconds or milliseconds; a selected unit needs explicit evidence/simulation basis. Do not infer timing when absent.
3. Track active transactions separately from persistent loan IDs. Reject early retrieval, retrieval without a pending transaction, a new submit while pending, changed async IDs and conflicting loan IDs before applying the event.
4. Merge only nonblank, consistent identifiers; non-200 terminates retrieval while preserving previous loan identity. Partial updates interval/async ID; terminal states remove polling fields.
5. Read local response files relative to the scenario. Report each applied/skipped event, issues and hashes; omit IDs unless requested. No request, sleep, authentication or network hooks.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
timestamp(value)
replay(scenario, directory, reference, include_values=False, schema=None)
```

Local module dependencies:

- `.common: LPAError`
- `.responses: analyze_response`

## Verify

Test chronology, missing timing basis, changing intervals, early calls, transport errors and atomic identity preservation.

Run the relevant checks in [ACCEPTANCE.md](../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `7072` bytes; SHA-256: `8ab8dfcd568a72b16a1b017ca5c3b0bc558e63dc419480ab5d3409a5c4957e57`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../FILE_INDEX.md)
