# Rebuild `examples/synthetic/client.json`

**Purpose:** Fabricated input

**Delivery role:** demo / regression verification. See [client delivery guidance](../../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** R1/R2 for target semantics; synthetic example generator. Resolve these through [INPUT_REFERENCES.md](../../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Create this file with scripts/create_synthetic_example.py. Preserve two independent borrower/asset scopes and explicit owner relationships. The profile uses nine confirmed mappings with reasons tied only to this fabricated example.
2. Never copy real borrower records into the fixture. Keep the synthetic label and limitations. Do not use this profile as proof of a full loan mapping.

## Output structure

Top-level keys: `borrowers`, `assets`.

Baseline collection sizes (metadata only): `borrowers`: 2, `assets`: 2.

## Verify

Generator is repeatable; profile-check and request-build pass implemented checks; omitted real-loan requirements remain visible in coverage.

Run the relevant checks in [ACCEPTANCE.md](../../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `612` bytes; SHA-256: `d9d6234c6a47ba2ad9031d02b9e0aaf29f2b75e7adc05f5a6e6df1a3ecd39ed3`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../../FILE_INDEX.md)
