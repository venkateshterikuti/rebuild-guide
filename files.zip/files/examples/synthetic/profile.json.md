# Rebuild `examples/synthetic/profile.json`

**Purpose:** Reviewed-for-example ordered mapping profile

**Delivery role:** demo / regression verification. See [client delivery guidance](../../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** R1/R2 for target semantics; synthetic example generator. Resolve these through [INPUT_REFERENCES.md](../../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Create this file with scripts/create_synthetic_example.py. Preserve two independent borrower/asset scopes and explicit owner relationships. The profile uses nine confirmed mappings with reasons tied only to this fabricated example.
2. Never copy real borrower records into the fixture. Keep the synthetic label and limitations. Do not use this profile as proof of a full loan mapping.

## Output structure

Top-level keys: `profile_format`, `client_id`, `catalog_id`, `scope`, `structural_review`, `mappings`, `template`, `decisions`, `unresolved`, `synthetic`.

Baseline collection sizes (metadata only): `scope`: 2, `structural_review`: 2, `mappings`: 9, `template`: 3, `decisions`: 1, `unresolved`: 0.

## Verify

Generator is repeatable; profile-check and request-build pass implemented checks; omitted real-loan requirements remain visible in coverage.

Run the relevant checks in [ACCEPTANCE.md](../../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `9557` bytes; SHA-256: `e54672c613775efd2d6327d215941b1e736ada414dc6c9b08cf605f4a3b5f834`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../../FILE_INDEX.md)
