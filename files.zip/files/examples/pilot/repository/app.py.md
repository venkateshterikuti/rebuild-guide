# Rebuild `examples/pilot/repository/app.py`

**Purpose:** Initially unconnected sample loan application.

**Delivery role:** demo / regression verification. See [client delivery guidance](../../../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** Fabricated application design. Resolve these through [INPUT_REFERENCES.md](../../../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Implement save_draft with required borrower data, defensive deepcopy and a draft result. Implement assess(application, integration) initially returning status not_connected.
2. The demo replaces only the known unconnected statement with integration.submit(application). Keep this source fixture unconnected; the generated output copy is the connected example.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
save_draft(application)
assess(application, integration)
```

## Verify

Original draft behavior remains after integration; source fixture stays unchanged and the demo finds exactly one integration anchor.

Run the relevant checks in [ACCEPTANCE.md](../../../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `443` bytes; SHA-256: `953aec663013817b0f0c8508500a40f14986c7e5c0c8bba717eab292376bd863`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../../../FILE_INDEX.md)
