# Rebuild `examples/pilot/repository/tests/test_drafts.py`

**Purpose:** Existing sample-application regression tests.

**Delivery role:** demo / regression verification. See [client delivery guidance](../../../../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** Pilot app contract. Resolve these through [INPUT_REFERENCES.md](../../../../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../../../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Write two unittest cases: saving a draft preserves caller data and missing required draft data is rejected. These tests must pass before/after adding the integration behavior.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
class DraftTests(unittest.TestCase)
  test_saving_a_draft_preserves_the_callers_data(self)
  test_incomplete_draft_is_rejected(self)
```

## Verify

Demo runs these existing tests along with its generated integration test.

Run the relevant checks in [ACCEPTANCE.md](../../../../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `555` bytes; SHA-256: `9798df864d35cbadaaa72dbb2df84a174d4a13eb2a22027c3e8f33494e2a4920`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../../../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../../../../FILE_INDEX.md)
