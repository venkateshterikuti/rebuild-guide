# Rebuild `examples/pilot/profile.json`

**Purpose:** Pilot mapping with managed resubmission identifiers.

**Delivery role:** demo / regression verification. See [client delivery guidance](../../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** R1 field references 101, 195, 197, 424, 425, 425.5, 433; R2 order; synthetic base profile. Resolve these through [INPUT_REFERENCES.md](../../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Extend the base example to sixteen mappings by adding SubjectLoan role, purpose/mortgage and stored LPA/AUS identifiers. Obtain exact target values/contexts from the cited rows.
2. Insert LOANS before PARTIES in the reviewed order. Map reserved $/__lpa/lpa and $/__lpa/aus optional arrays through repeated identifier nodes, with @/value scoped to each entry.
3. Keep catalog pin, confirmed-for-example rationale, structural review, empty unresolved list and synthetic marker. Empty initial arrays and populated resubmission arrays must both validate.

## Output structure

Top-level keys: `profile_format`, `client_id`, `catalog_id`, `scope`, `structural_review`, `mappings`, `template`, `decisions`, `unresolved`, `synthetic`.

Baseline collection sizes (metadata only): `scope`: 2, `structural_review`: 2, `mappings`: 16, `template`: 3, `decisions`: 2, `unresolved`: 0.

## Verify

Native request XSD accepts both initial/resubmission XML; the runtime verifies the stored identifiers are serialized exactly once.

Run the relevant checks in [ACCEPTANCE.md](../../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `15797` bytes; SHA-256: `573bb5bdd07d9e06d46fd1469b8ad9decd31263ad7e1ac75d132aee33b57f60c`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../../FILE_INDEX.md)
