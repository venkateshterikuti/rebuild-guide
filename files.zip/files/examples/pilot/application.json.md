# Rebuild `examples/pilot/application.json`

**Purpose:** Synthetic application input for the end-to-end reference client.

**Delivery role:** demo / regression verification. See [client delivery guidance](../../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** Synthetic fixture design; no original input content. Resolve these through [INPUT_REFERENCES.md](../../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Extend the fabricated borrower/asset sample with a loan-purpose object and stable application_id/submission_id strings. The reference scenario is a Conventional purchase; it is not a full loan.
2. Keep repeated ownership and synthetic data intact. Do not include reserved __lpa: the runtime injects stored identifiers.

## Output structure

Top-level keys: `borrowers`, `assets`, `loan`, `application_id`, `submission_id`.

Baseline collection sizes (metadata only): `borrowers`: 2, `assets`: 2, `loan`: 1.

## Verify

The same operation ID deduplicates; a new explicit resubmission retains loan identity; unexpected reserved context fails.

Run the relevant checks in [ACCEPTANCE.md](../../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `737` bytes; SHA-256: `2ebe950528c6440080a661817bb24000e7c75106a17881c1db5caa1ffa710ee2`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../../FILE_INDEX.md)
