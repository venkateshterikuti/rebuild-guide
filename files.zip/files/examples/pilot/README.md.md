# Rebuild `examples/pilot/README.md`

**Purpose:** Pilot fixture explanation

**Delivery role:** demo / regression verification. See [client delivery guidance](../../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** Verified implementation behavior; R0 for intent and R1–R9 only as references where relevant. Resolve these through [INPUT_REFERENCES.md](../../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Write concise original documentation covering initially unconnected app, five generated changes, fabricated data, reference-only profile and mock assumptions. Link local deliverables with relative paths so the pack relocates.
2. Keep source evidence, implementation decisions and mock assumptions distinct. The guide is not a place to copy source documents. Do not claim any compiler/service/provider check that was not run.


## Verify

Resolve all local links and commands against implemented files; validation claims match recorded checks, not copied historical prose.

Run the relevant checks in [ACCEPTANCE.md](../../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `1113` bytes; SHA-256: `5be05faf65d56f9961ebe9b83c639d5f04787ce36534858b9b95d9d377d8871a`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../../FILE_INDEX.md)
