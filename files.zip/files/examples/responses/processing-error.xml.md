# Rebuild `examples/responses/processing-error.xml`

**Purpose:** Synthetic processing-error response fixture.

**Delivery role:** demo / regression verification. See [client delivery guidance](../../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** R3 structure and R4/R5 schema, not a real saved service exchange. Resolve these through [INPUT_REFERENCES.md](../../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Construct a synthetic response envelope validated against the separate response schema, with request and response DEAL markers obtained from the guide. Keep all identifying values fabricated.
2. For Partial fixtures keep the same transaction/loan identity and change the interval between the two files. Completed has result data and no active polling; processing-error has a processing error from the supplied partial reference and no active polling.
3. Include echo separation and allow tests to mutate order/namespace/status/IDs. Use the source schema for element order, occurrence and namespace details; do not embed input schema text in this guide.


## Verify

Each fixture passes response XSD and expected interpretation. Replay and mutation tests exercise actual parser behavior, including omissions/conflicts.

Run the relevant checks in [ACCEPTANCE.md](../../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `2977` bytes; SHA-256: `3811cccf7c14b630f5992daf45c3286ef2b6b89d24adb051d5333fe0e79fca03`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../../FILE_INDEX.md)
