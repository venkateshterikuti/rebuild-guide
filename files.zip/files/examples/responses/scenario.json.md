# Rebuild `examples/responses/scenario.json`

**Purpose:** Chronological saved-response replay example.

**Delivery role:** demo / regression verification. See [client delivery guidance](../../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** Synthetic response fixtures and replay interface. Resolve these through [INPUT_REFERENCES.md](../../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Use scenario_format 1, explicit simulated timing unit/basis and four chronological events. Exercise initial Partial, changed Partial interval, completion, and another submission returning a processing error.
2. Use relative local response paths and HTTP status metadata. Choose timestamps that obey each supplied interval. All identities and observed times are synthetic.

## Output structure

Top-level keys: `scenario_format`, `timing`, `events`.

Baseline collection sizes (metadata only): `timing`: 2, `events`: 4.

## Verify

Replay succeeds with timing enforcement and persistent IDs; early retrieval/chronology mutations fail appropriately.

Run the relevant checks in [ACCEPTANCE.md](../../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `798` bytes; SHA-256: `1a54924e89fac2fb80fbbdf0c8f82ef5663c26516b302adf0dc3b702d02b5e3b`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../../FILE_INDEX.md)
