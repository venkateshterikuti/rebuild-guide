# Rebuild `lpa-project.json`

**Purpose:** Select the local evidence and derived references.

**Delivery role:** runtime references / provenance. See [client delivery guidance](../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** R1, R2 and reconstructed/derived output recipes. Resolve these through [INPUT_REFERENCES.md](../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Set release and relative paths for workbook, native schema root, request entry, catalog, rules, error reference, response schema root/manifest and vendor reference.
2. Calculate response_schema_id with the canonical digest of the reconstructed manifest. Obtain schema entry paths from the supplied sources; do not paste hashes from this guide over changed content.
3. Keep paths relative to configuration for relocatability. No API endpoint, credential or live-connect setting belongs here.

## Output structure

Top-level keys: `release`, `workbook`, `schema_root`, `request_entry`, `catalog`, `rules`, `error_reference`, `response_schema_root`, `response_schema_manifest`, `response_schema_id`, `credit_vendor_reference`.

## Verify

Toolkit loads from a different working directory; native and response pins fail on drift.

Run the relevant checks in [ACCEPTANCE.md](../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `753` bytes; SHA-256: `bccc22d60c5db0e42c4f2214a8bf4a1bec6c761a02a78e38388a44c535c22aff`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../FILE_INDEX.md)
