# Rebuild `scripts/create_synthetic_example.py`

**Purpose:** Regenerate only the fabricated request example and reviewed-for-example profile.

**Delivery role:** developer release tooling. See [client delivery guidance](../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** R1/R2 for target structure; fabricated source data. Resolve these through [INPUT_REFERENCES.md](../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Load the existing catalog and derive field keys by UID. Use profile-init shape, mark the example synthetic and establish its scope/structure only for fabricated data.
2. Create two borrowers and two assets with explicit owner-role labels, including a zero-valued savings asset and an Other asset. Use source-specific enum translations and decimal2 without implicit rounding.
3. Construct the ordered template for request version fields, assets, individual/role data and ownership relationships. Obtain version constants and target field paths from R1/R2 rather than this guide.
4. Write the two examples/synthetic JSON targets via shared deterministic I/O. Never use this script to approve real-client mappings.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
main()
```

Local module dependencies:

- `lpa_tools.common: read_json, write_json`
- `lpa_tools.mapping: init_profile`

## Verify

Regenerated examples validate and exercise repeats/ownership/zero; the native sources are untouched.

Run the relevant checks in [ACCEPTANCE.md](../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `4105` bytes; SHA-256: `267b90f735d89640740166df87a3df16389740f5019495ad807da333b62e0b8f`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../FILE_INDEX.md)
