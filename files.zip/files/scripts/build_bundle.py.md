# Rebuild `scripts/build_bundle.py`

**Purpose:** Create the explicit, deterministic starter distribution.

**Delivery role:** developer release tooling. See [client delivery guidance](../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** Target-file inventory and lpa-project.json; no additional domain source. Resolve these through [INPUT_REFERENCES.md](../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Collect exactly the product roots and specific files described by the baseline inventory: code/templates, skill/adapters, four product docs, tests/examples/KB, response schema, native workbook and complete configured request XSD tree, root metadata and two product scripts.
2. Exclude bytecode, recordings, extraction tooling, review scratch, outputs, client data and environments. Do not glob the project root into the ZIP.
3. Sort target paths; preserve file bytes; write ZIP entries with fixed 2026-01-01 timestamp, regular 0644 attributes and DEFLATE level 6. Build a separate internal manifest with version and each file SHA-256; the manifest does not hash itself.
4. Name output dist/lpa-integration-starter-<version>.zip and report file count/bytes. Keep the rebuild guide separate from this existing release.

## Baseline callable/data interface

These are generated-tool interfaces and test names, not source-document contents. Preserve compatible public behavior; private helpers may be implemented differently.

```text
main()
```

Local module dependencies:

- `lpa_tools: __version__`
- `lpa_tools.common: read_json`

## Verify

Check all file hashes and the exclusion list, then relocate/install/run the pack. Baseline has 93 payload files plus its manifest.

Run the relevant checks in [ACCEPTANCE.md](../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `2290` bytes; SHA-256: `af3b3854e3d977861ba9fe3a1957f4c35d6ccca9a5b05ff2c4103126b8c5e894`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../FILE_INDEX.md)
