# Rebuild `schemas/response_v6.1/manifest.json`

**Purpose:** Independent pin for the reconstructed response schema closure.

**Delivery role:** runtime references / provenance. See [client delivery guidance](../../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** R4/R5 reconstruction and seven unchanged R2 dependencies. Resolve these through [INPUT_REFERENCES.md](../../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Create manifest_format 1, response entry relative path, reconstructed_response_wrapper source basis, and sorted relative paths/SHA-256 hashes of all nine XSD files.
2. Calculate the manifest canonical digest and set it in lpa-project.json. Do not add archives to the runtime or reuse the request-catalog pin.

## Output structure

Top-level keys: `manifest_format`, `entry`, `source_basis`, `schemas`.

Baseline collection sizes (metadata only): `schemas`: 9.

## Verify

Changing the manifest or any response XSD causes setup to fail until reviewed; metadata and imported file closure agree.

Run the relevant checks in [ACCEPTANCE.md](../../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `1500` bytes; SHA-256: `82a405628e5dae48eea3898a97be1cd05d1648cd59d841df5b1b4542ff88d083`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../../FILE_INDEX.md)
