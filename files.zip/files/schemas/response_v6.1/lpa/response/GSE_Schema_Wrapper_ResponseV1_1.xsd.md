# Rebuild `schemas/response_v6.1/lpa/response/GSE_Schema_Wrapper_ResponseV1_1.xsd`

**Purpose:** Reviewed reconstruction of the response-specific wrapper.

**Delivery role:** runtime references / provenance. See [client delivery guidance](../../../../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** R4, R5; optional D2, D6, D7. Resolve these through [INPUT_REFERENCES.md](../../../../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../../../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Reconcile both recordings by displayed line numbers and overlapping frames; inspect images for ambiguous OCR, comments, import paths, facets and group cardinality. Do not substitute request schema semantics.
2. Produce the response wrapper with 1,224 active extension definitions: 1,190 empty restrictions, 34 enabled definitions, and four primitive overrides. Exclude inactive commented definitions; retain their provenance count separately. Counts alone do not establish correctness.
3. Use local imports/redefine and the unchanged native dependency files. Record every declaration name, source line, kind, groups and reviewed evidence frame paths in reconstruction.json. Do not copy those declarations into the rebuild guide.
4. Compile against the response entry with a confined resolver and exercise positive and negative response fixtures. Formatting may be normalized; never claim original byte identity.


## Verify

Local compilation, unsupported-extension rejection, ordering tests, declaration coverage/order and source-frame audit pass. Pin the actual reconstructed bytes, not an assumed historical hash.

Run the relevant checks in [ACCEPTANCE.md](../../../../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `331677` bytes; SHA-256: `2884a19fb44d48ce101bf5ed38278b787d8d40731a07168c035e50c343c8e2f0`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../../../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../../../../FILE_INDEX.md)
