# Rebuild `schemas/response_v6.1/lpa/response/LPALoanAssessmentServiceResponse_v1.0.0.xsd`

**Purpose:** Checked transcription of the response entry schema.

**Delivery role:** runtime references / provenance. See [client delivery guidance](../../../../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** R4 near 00:20; optional D1. Resolve these through [INPUT_REFERENCES.md](../../../../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../../../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Transcribe the entry from the supplied frame or preserve the reviewed D1 transcription when supplied. Verify namespace, response envelope declaration, referenced MESSAGE and response-wrapper import against the image.
2. Preserve source version comments as evidence even when they reference an older version; do not rename the entry to the request contract. Keep all imports local.


## Verify

Well-formed XML and compilation with the separate wrapper pass; record reconstruction provenance and actual byte hash.

Run the relevant checks in [ACCEPTANCE.md](../../../../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `1042` bytes; SHA-256: `c970f98c53b63ea85bc65e541f7417e4b057d514729aa4e3cc1545eaf23afb2f`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../../../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../../../../FILE_INDEX.md)
