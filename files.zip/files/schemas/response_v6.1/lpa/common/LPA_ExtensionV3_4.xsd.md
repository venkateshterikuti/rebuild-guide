# Rebuild `schemas/response_v6.1/lpa/common/LPA_ExtensionV3_4.xsd`

**Purpose:** Unchanged native dependency copied into the independent response tree.

**Delivery role:** runtime references / provenance. See [client delivery guidance](../../../../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** R2. Resolve these through [INPUT_REFERENCES.md](../../../../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../../../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Find the same relative lpa/common or mismo path under the supplied native schema root and copy it byte-for-byte into the response tree. This is dependency reuse, not a new transcription.
2. Keep imports working within the response tree and include this file in its separate manifest. Do not change the native request source.


## Verify

Bytes equal the native source copy; confined response compilation succeeds and the manifest hashes the actual file.

Run the relevant checks in [ACCEPTANCE.md](../../../../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `154108` bytes; SHA-256: `13510e670dd8a1a8fd8f78bf5788a0219cc671924c3efeb01f612ab6a2dc44f1`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../../../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../../../../FILE_INDEX.md)
