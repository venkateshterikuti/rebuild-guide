# Rebuild `schemas/response_v6.1/reconstruction.json`

**Purpose:** Audit trail for each reconstructed response declaration.

**Delivery role:** runtime references / provenance. See [client delivery guidance](../../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** R4/R5; optional D2/D6/D7. Resolve these through [INPUT_REFERENCES.md](../../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Recreate an evidence table of 1,224 active declaration names, displayed source lines, empty/enabled kind, group attributes and actual reviewed frame references.
2. Record wrapper line count, active/empty/enabled/inactive/primitive counts, unchanged dependency provenance and the compilation result. Obtain details from the referenced material, not this guide.
3. Do not state an image was reviewed if it was not. Retain limitations about original bytes and service acceptance. The runtime schema manifest is a separate file.

## Output structure

Top-level keys: `format`, `origin`, `recorded_wrapper_lines`, `active_extension_types`, `empty_extension_restrictions`, `enabled_extension_types`, `inactive_commented_definitions`, `primitive_overrides`, `native_dependencies`, `compilation`, `limitations`, `declarations`.

Baseline collection sizes (metadata only): `limitations`: 2, `declarations`: 1224.

## Verify

Declaration audit matches the reconstructed wrapper and references existing supplied frames; reported compilation is actually run.

Run the relevant checks in [ACCEPTANCE.md](../../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `401813` bytes; SHA-256: `278a3ae38f5883444a69abf2865f2faa4f3b03e888351210ea429fd8bcc84230`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../../FILE_INDEX.md)
