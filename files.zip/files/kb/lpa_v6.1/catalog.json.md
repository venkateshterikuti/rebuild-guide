# Rebuild `kb/lpa_v6.1/catalog.json`

**Purpose:** Native request field/evidence catalog

**Delivery role:** runtime references / provenance. See [client delivery guidance](../../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** R1, R2. Resolve these through [INPUT_REFERENCES.md](../../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Generate exclusively through catalog.py after verifying the source layout; do not author 404 records by hand. Preserve source rows/formatting and stable IDs.

## Output structure

Top-level keys: `catalog_format`, `release`, `source`, `fields`, `source_rows`, `reference_tables`, `interpretation`, `catalog_id`.

Baseline collection sizes (metadata only): `source`: 3, `fields`: 404, `source_rows`: 858, `reference_tables`: 6.

## Verify

Validate JSON structure and source provenance; compare counts only for the same supplied baseline; keep unknowns and partial coverage explicit.

Run the relevant checks in [ACCEPTANCE.md](../../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `5256475` bytes; SHA-256: `13b1b007a39541a36ea52e869d2757b629950814bb16af9127825fea470757e6`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../../FILE_INDEX.md)
