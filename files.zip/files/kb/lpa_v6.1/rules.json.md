# Rebuild `kb/lpa_v6.1/rules.json`

**Purpose:** Selected executable business-rule definitions

**Delivery role:** runtime references / provenance. See [client delivery guidance](../../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** R1, R2. Resolve these through [INPUT_REFERENCES.md](../../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Use the selection/reference table below to author the 26 reviewed rules. Read the cited input rows for actual selectors, values, boundaries and applicability. Keep ruleset format, independent rule version, catalog pin, review basis and five unimplemented categories; do not blindly bump its version with the package.

## Output structure

Top-level keys: `ruleset_format`, `version`, `catalog_id`, `review_basis`, `rules`, `unimplemented`.

Baseline collection sizes (metadata only): `rules`: 26, `unimplemented`: 5.

## Selected-rule source references

Read the cited input locations for values, boundaries and conditions. Their contents are deliberately not reproduced here. Rule IDs/kinds below identify our implementation decisions.

| Rule ID | Evaluator kind | Source reference |
| --- | --- | --- |
| `version-1` | `values` | 7-LPA XML Req File Data Reqts, row 5, F5 |
| `version-2` | `values` | 7-LPA XML Req File Data Reqts, row 8, F8 |
| `version-4` | `values` | 7-LPA XML Req File Data Reqts, row 9, F9 |
| `asset-other-description` | `values` | 7-LPA XML Req File Data Reqts, row 27, F27 |
| `xlink-integrity` | `xlink_integrity` | 10-xlink RELATIONSHIPs, rows 12, 13 |
| `asset-type-required` | `assertion` | 7-LPA XML Req File Data Reqts, row 26, F26 |
| `non_reo-asset-value` | `assertion` | 7-LPA XML Req File Data Reqts, row 25, F25 |
| `borrower-firstname` | `assertion` | 7-LPA XML Req File Data Reqts, row 410, F410 |
| `borrower-lastname` | `assertion` | 7-LPA XML Req File Data Reqts, row 411, F411 |
| `alias-firstname` | `assertion` | 7-LPA XML Req File Data Reqts, row 397, F397 |
| `alias-lastname` | `assertion` | 7-LPA XML Req File Data Reqts, row 398, F398 |
| `phone-max-length` | `assertion` | 7-LPA XML Req File Data Reqts, row 407, F407 |
| `marital-status-values` | `assertion` | 7-LPA XML Req File Data Reqts, row 449, F449 |
| `loan-role-values` | `assertion` | 7-LPA XML Req File Data Reqts, row 179, F179 |
| `subject-loan-purpose` | `assertion` | 7-LPA XML Req File Data Reqts, row 381, F381 |
| `subject-mortgage-type` | `assertion` | 7-LPA XML Req File Data Reqts, row 382, F382 |
| `subject-property-usage` | `assertion` | 7-LPA XML Req File Data Reqts, row 119, F119 |
| `asset-owner-role-and-presence` | `asset_ownership` | 10-xlink RELATIONSHIPs, rows 12, 13 |
| `xlink-sequence-required` | `assertion` | 10-xlink RELATIONSHIPs, row 3 |
| `sequence-unique-siblings` | `sequence_uniqueness` | mismo/MISMO_3.4.0_B324.xsd |
| `message-deal-sets` | `occurs` | 12-Container Cardinality, row 10 |
| `deal-set-count` | `occurs` | 12-Container Cardinality, row 11 |
| `deals-count` | `occurs` | 12-Container Cardinality, row 12 |
| `deal-count` | `occurs` | 12-Container Cardinality, row 13 |
| `asset-count` | `occurs` | 12-Container Cardinality, row 19 |
| `relationship-count` | `occurs` | 10-xlink RELATIONSHIPs, row 8 |

## Verify

Validate JSON structure and source provenance; compare counts only for the same supplied baseline; keep unknowns and partial coverage explicit.

Run the relevant checks in [ACCEPTANCE.md](../../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `11706` bytes; SHA-256: `f4984c4410e4e55a03b3a879dc85bc50e96b179a09c0620ad2da5d9c78bab767`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../../FILE_INDEX.md)
