# Rebuild `kb/lpa_v6.1/errors.json`

**Purpose:** Partial HTTP/processing-error lookup

**Delivery role:** runtime references / provenance. See [client delivery guidance](../../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** R3, R7; optional D4. Resolve these through [INPUT_REFERENCES.md](../../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Transcribe only the six HTTP and fourteen processing-code records covered by the reviewed supplied evidence. Preserve null categories, use labeled editorial paraphrases and list missing dictionaries/authentication details. Do not turn entries into retry rules.

## Output structure

Top-level keys: `reference_format`, `coverage`, `source`, `http_status_codes`, `processing_error_codes`, `limitations`, `missing`.

Baseline collection sizes (metadata only): `source`: 4, `http_status_codes`: 6, `processing_error_codes`: 14, `limitations`: 3, `missing`: 3.

## Verify

Validate JSON structure and source provenance; compare counts only for the same supplied baseline; keep unknowns and partial coverage explicit.

Run the relevant checks in [ACCEPTANCE.md](../../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `3978` bytes; SHA-256: `b7bf39eeeefa88e03155577560c5d9055530b6abb8b752fa06dcb6e677f9603a`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../../FILE_INDEX.md)
