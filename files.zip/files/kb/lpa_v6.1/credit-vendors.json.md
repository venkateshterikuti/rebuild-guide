# Rebuild `kb/lpa_v6.1/credit-vendors.json`

**Purpose:** Historical CRC/technical-affiliate lookup

**Delivery role:** runtime references / provenance. See [client delivery guidance](../../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** R6; optional D3. Resolve these through [INPUT_REFERENCES.md](../../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Normalize the eight CRC and thirty-seven affiliate rows for the reviewed product columns. Preserve string codes/leading zeroes, null blank cells, product scope, date evidence and unresolved effective dates. Do not invent unlisted combinations or current eligibility.

## Output structure

Top-level keys: `reference_format`, `status`, `source`, `null_meaning`, `limitations`, `credit_reporting_companies`, `technical_affiliates`.

Baseline collection sizes (metadata only): `source`: 3, `limitations`: 4, `credit_reporting_companies`: 8, `technical_affiliates`: 37.

## Verify

Validate JSON structure and source provenance; compare counts only for the same supplied baseline; keep unknowns and partial coverage explicit.

Run the relevant checks in [ACCEPTANCE.md](../../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `14633` bytes; SHA-256: `7e037696aa2bdaabd773150b8b2f9fd128cafff9e1c7068f7471190b2d45334f`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../../FILE_INDEX.md)
