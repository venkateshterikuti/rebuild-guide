# Rebuild `skills/lpa-integrate/SKILL.md`

**Purpose:** Shared agent workflow for actual application integration.

**Delivery role:** agent development workflow. See [client delivery guidance](../../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** User intent, current tool interfaces and local-only restriction. Resolve these through [INPUT_REFERENCES.md](../../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Use YAML frontmatter with name lpa-integrate and a precise description. Route to application/mapping/response references without loading all source material by default.
2. For an integration request, inspect the repository, establish semantic evidence, create reviewed mappings, implement actual application changes and run local mock/regression tests. XML generation alone is insufficient.
3. Preserve no-FM access, source pins, source-vs-simulation distinction, partial coverage and reconstructed response provenance. Candidate scores do not authorize confirmation. Avoid repeated approval requests for already established meanings/actions.
4. Cover upgrade, existing XML, saved responses, transaction work, vendor lookup and language bridges with the exact available commands. Deliver runnable code/evidence and explicit remaining decisions; extraction is not a product step.


## Verify

Validate frontmatter and reference links; use a realistic local application scenario. Metadata validity does not certify provider behavior.

Run the relevant checks in [ACCEPTANCE.md](../../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `5987` bytes; SHA-256: `a6024668cef3d9b928157489df0be82a3d21b51e4aa9641502db7dad02d6aa02`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../../FILE_INDEX.md)
