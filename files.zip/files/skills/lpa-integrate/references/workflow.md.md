# Rebuild `skills/lpa-integrate/references/workflow.md`

**Purpose:** Focused workflow agent reference.

**Delivery role:** agent development workflow. See [client delivery guidance](../../../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** Tool contracts and cited local evidence. Resolve these through [INPUT_REFERENCES.md](../../../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Describe source/profile/schema pinning; pointer syntax; supported transforms; ordered templates; repeats/relationships; confirmed semantic reasons; rule gaps; source typography; upgrade and handoff with commands and behavioral examples using fabricated data only. Keep this deeper guidance linked from SKILL.md.
2. Explain limits and failed states alongside happy behavior. Refer to source materials rather than embedding their content. Do not make provider-specific APIs a requirement.


## Verify

Commands exist; documented profile/runtime fields match implementation; source meanings are never auto-approved or inferred from mock success.

Run the relevant checks in [ACCEPTANCE.md](../../../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `9161` bytes; SHA-256: `677889fe565afb3d4901d968c2d4c1473b50b7d089f32f3d1e5810adb317f5e2`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../../../FILE_INDEX.md)
