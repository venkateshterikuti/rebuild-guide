# Rebuild `skills/lpa-integrate/references/responses.md`

**Purpose:** Focused responses agent reference.

**Delivery role:** agent development workflow. See [client delivery guidance](../../../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** Tool contracts and cited local evidence. Resolve these through [INPUT_REFERENCES.md](../../../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Describe response namespace/DEAL selection; separate schema; processing versus underwriting; private values; saved replay with explicit timing; partial errors/opaque feedback and disputed source details with commands and behavioral examples using fabricated data only. Keep this deeper guidance linked from SKILL.md.
2. Explain limits and failed states alongside happy behavior. Refer to source materials rather than embedding their content. Do not make provider-specific APIs a requirement.


## Verify

Commands exist; documented profile/runtime fields match implementation; source meanings are never auto-approved or inferred from mock success.

Run the relevant checks in [ACCEPTANCE.md](../../../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `2926` bytes; SHA-256: `679667bbbc1407d5850051fc3ef7b05fd47776c82d69c27672664a1dd39f01a6`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../../../FILE_INDEX.md)
