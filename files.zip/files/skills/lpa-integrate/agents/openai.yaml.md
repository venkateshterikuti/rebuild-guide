# Rebuild `skills/lpa-integrate/agents/openai.yaml`

**Purpose:** Optional agent UI metadata for the shared skill.

**Delivery role:** agent development workflow. See [client delivery guidance](../../../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** Skill purpose and provider metadata format. Resolve these through [INPUT_REFERENCES.md](../../../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Provide display_name, short_description and default_prompt that accurately request application inspection, reviewed mapping, implementation and mock verification. Preserve normal implicit invocation; do not add credentials, endpoints or invented provider options.


## Verify

YAML parses; the prompt invokes the actual shared skill and matches its scope. The runtime works without this metadata.

Run the relevant checks in [ACCEPTANCE.md](../../../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `296` bytes; SHA-256: `30aa052187a0a6f0490fa4a62cc73fd12a4fdd3e42f32afbda3ec745d12e17fe`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../../../FILE_INDEX.md)
