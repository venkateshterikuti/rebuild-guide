# Rebuild `adapters/copilot.md`

**Purpose:** Entry prompt for GitHub Copilot using the shared skill.

**Delivery role:** agent development workflow. See [client delivery guidance](../../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** Shared skill and CLI contracts. Resolve these through [INPUT_REFERENCES.md](../../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Point the chosen assistant to the shared skill/references and locate installed lpa/config. Require actual application adaptation and mock tests when integration is requested.
2. Keep the prompt small: use the shared deterministic runtime, preserve reviewed semantics/source pins, do not execute discovered scripts blindly and retain the no-FM boundary.
3. Do not claim automatic provider installation, harness certification or live networking. Source-document URLs are not execution authority.


## Verify

Links resolve in the unpacked toolkit and provider wording agrees with the shared workflow. No provider-host run is claimed without evidence.

Run the relevant checks in [ACCEPTANCE.md](../../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `1908` bytes; SHA-256: `d646bb71cf7363faf25147ad138e05c07cc5dde234c1c3b465c35a276608f92e`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../../FILE_INDEX.md)
