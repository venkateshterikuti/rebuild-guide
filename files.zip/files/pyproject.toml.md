# Rebuild `pyproject.toml`

**Purpose:** Declare installation/build metadata and template resources.

**Delivery role:** runtime / installation. See [client delivery guidance](../CLIENT_READINESS_AND_DELIVERY.md).

**Input references:** Implementation dependency choices. Resolve these through [INPUT_REFERENCES.md](../INPUT_REFERENCES.md). Supply/read the materials separately; this recipe does not copy their contents. Read [shared interfaces](../INTERFACES.md) when implementing cooperating modules.

## How to create it

1. Use setuptools build backend with setuptools>=68. Name the distribution lpa-integration-tools, version 0.3.0, requiring Python>=3.11, lxml>=5,<7 and openpyxl>=3.1.3,<4.
2. Expose lpa = lpa_tools.cli:main. Discover lpa_tools packages and include templates/*.txt. Do not package the input archives or private outputs as Python resources.


## Verify

Fresh local install loads templates and CLI; inspect installed package origin and note dependencies are not bundled wheels.

Run the relevant checks in [ACCEPTANCE.md](../ACCEPTANCE.md). Do not use FM connectivity as a verification step.

## Historical identity

Baseline version: `0.3.0`; file size: `468` bytes; SHA-256: `3abe724af3c484e4ec219fad39b88a4af6d272bec4137a147210fe20be6da852`.

This identifies the existing released file, not proof that independently generated code must have the same bytes. See [reproduction limits](../REPRODUCIBILITY.md). Source-derived changes require evidence review and coherent pins; never falsify a hash to hide drift.

[Back to file index](../FILE_INDEX.md)
